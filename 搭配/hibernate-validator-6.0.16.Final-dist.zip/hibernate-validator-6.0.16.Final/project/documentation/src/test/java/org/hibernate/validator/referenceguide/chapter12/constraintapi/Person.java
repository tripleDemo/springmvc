package org.hibernate.validator.referenceguide.chapter12.constraintapi;

public class Person {

	private String name;
}
